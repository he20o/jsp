package he20o.com.boardtest;

public class Testdto {

	public String no;
	public String title;
	public String id;
	public String datetime;
	public String hit;
	public String text;
	public String replyCount;
	public String replyOri;
	
	
	
	public Testdto(String no, String title, String id, String datetime, String hit, String text, String replyCount,
			String replyOri) {
		super();
		this.no = no;
		this.title = title;
		this.id = id;
		this.datetime = datetime;
		this.hit = hit;
		this.text = text;
		this.replyCount = replyCount;
		this.replyOri = replyOri;
	}



	public Testdto(String title, String id, String text) {
		super();
		this.title = title;
		this.id = id;
		this.text = text;
	}



	public Testdto(String title, String text) {
		super();
		this.title = title;
		this.text = text;
	}
	
	
	
	
	
	
	
}
