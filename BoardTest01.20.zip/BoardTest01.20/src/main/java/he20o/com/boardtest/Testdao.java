package he20o.com.boardtest;

import java.sql.ResultSet;
import java.util.ArrayList;

public class Testdao extends Dao {
	
	/* (1/5 쓰기) */
	
	public void write(Testdto wr) {
		connect();			//고정 1,2,3
		String sql = String.format("insert into %s (b_title,b_id,b_text) values ('%s','%s','%s')", Testdb.TABLE_D_BOARDTEST,wr.title,wr.id,wr.text);
		update(sql);		//고정 4
		close();			//고정 5
	}
	

	/* (2/5 읽기) */
	public Testdto read(String no) {
		connect();
		Testdto post = null;
		try {
			String sql = String.format("select * from %s where b_no=%s", Testdb.TABLE_D_BOARDTEST,no);
			System.out.println("sql:"+sql);
			ResultSet rs = st.executeQuery(sql);
			rs.next();
			post = new Testdto(rs.getString("b_no"),
					rs.getString("b_title"),
					rs.getString("b_id"),
					rs.getString("b_datetime"),
					rs.getString("b_hit"),
					rs.getString("b_text"),
					rs.getString("b_reply_count"),
					rs.getString("b_reply_ori"));
		}catch (Exception e) {
			e.printStackTrace();
		}
		close();
		return post;
	}
	
	
	/* (3/5) 리스트 */
	public ArrayList<Testdto> list(String page){
		connect();
		ArrayList<Testdto> posts = new ArrayList<>();
		try {
			int startIndex = ((Integer.parseInt(page))-1)*3;
			String sql = String.format("select * from %s limit %s,3", Testdb.TABLE_D_BOARDTEST,startIndex);
			System.out.println("sql:"+sql);
			ResultSet rs = st.executeQuery(sql);
			while(rs.next()) {
				posts.add(new Testdto(rs.getString("b_no"),
						rs.getString("b_title"),
						rs.getString("b_id"),
						rs.getString("b_datetime"),
						rs.getString("b_hit"),
						rs.getString("b_text"),
						rs.getString("b_reply_count"),
						rs.getString("b_reply_ori")));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		connect();
		return posts;
	}
	
	
	/* (4/5) 삭제 */
	public void del(String no) {
		connect();
		String sql = String.format("delete from %s where b_no=%s",Testdb.TABLE_D_BOARDTEST,no);
		update(sql);
		close();
	}
	
	/* (5/5) 수정 */
	public void edit(Testdto d, String no) {
		connect();
		String sql = String.format("update %s set b_title='%s',b_text='%s' where b_no=%s",Testdb.TABLE_D_BOARDTEST,d.title,d.text,no);
		update(sql);
		close();
	}
	
	
	/* 전체 글 수 구하기 */
	public int getPostCount() {
		int count = 0;
		connect();
		try {
			String sql = String.format("select count(*) from %s",Testdb.TABLE_D_BOARDTEST);
			ResultSet rs = st.executeQuery(sql);
			rs.next();
			count = rs.getInt("count(*)");
		}catch (Exception e) {
			e.printStackTrace();
		}
		close();
		return count;
	}
}
