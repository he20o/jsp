package he20o.com.boardtest;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class Dao {
	
	Connection con = null;
	Statement st = null;
	
	void connect() {
		try {
			Class.forName(Testdb.DB_PACKAGE);			//고정 1
			con = DriverManager.getConnection(Testdb.DB_URL,Testdb.DB_ID,Testdb.DB_PW);			//고정 2
			st = con.createStatement();			//고정 3
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
		
		void update(String sql) {
			try {
				st.executeUpdate(sql);
			}catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		void close() {
			try {
				st.close();			//고정 4
				con.close();			//고정 5
			} catch(Exception e) {
				e.printStackTrace();
			}
	}

}
