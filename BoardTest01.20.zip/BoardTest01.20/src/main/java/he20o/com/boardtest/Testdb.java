package he20o.com.boardtest;

public class Testdb {
	
	static public final String DB_PACKAGE = "com.mysql.cj.jdbc.Driver";		//mysql
	
	static private String DB_NAME = "BoardTest";
	static private String DB_URL_MYSQL = "jdbc:mysql://localhost:3306/"+DB_NAME;		//mysql
	static public String DB_URL = DB_URL_MYSQL;				//DB바뀌면 여기 바꿔주기
	static public String DB_ID = "root";
	static public String DB_PW = "0000";
	
	/* table들 */
	
	public static final String TABLE_D_BOARDTEST = "Test";
	}
